// KI-Assistent (links in der Mitte). Eigene Datei, eigener Speicher-Schlüssel.
(() => {
  const $ = (s) => document.querySelector(s);
  const KEY = "gbg_ai";
  const MODEL = "claude-haiku-4-5-20251001";
  // Kein Schlüssel eingebaut: Jeder trägt unter ⚙ seinen eigenen ein.
  const DEFAULT_KEY = "";
  // Adresse deines Mini-Servers (Cloudflare Worker). Dort liegt der geheime Schlüssel, nicht hier.
  const WORKER_URL = "https://devvault.cloudcore459.workers.dev";
  const MAX_IMAGES = 4;
  const CATS = ["Allgemein", "Lernen", "Schreiben", "Alltag", "Kochen", "Reisen", "Gesundheit", "Technik erklären"];

  const panel = $("#ai"), log = $("#aiLog"), ta = $("#aiText"), sendBtn = $("#aiSend");
  const thumbs = $("#aiThumbs"), setup = $("#aiSetup");
  let state = { key: "", cat: "", history: [] };   // history: {role, text, images:n}
  let pending = [];                                // {data, type, url}
  let busy = false;

  const store = {
    load: (cb) => chrome.storage.local.get(KEY, (r) => cb((r && r[KEY]) || {})),
    save: () => chrome.storage.local.set({ [KEY]: { key: state.key === DEFAULT_KEY ? "" : state.key, cat: state.cat, history: state.history.slice(-40) } })
  };

  const SYSTEM = (cat) =>
    "Du bist der KI-Assistent in der Browser-Erweiterung DevVault. Antworte freundlich, klar und knapp in der Sprache des Nutzers (meist Deutsch). " +
    "Du beantwortest Fragen aller Art und kannst Bilder beschreiben und erklären. " +
    "Du schreibst KEINE Skripte, keinen Programmcode und hilfst nicht beim Programmieren oder bei Programmen. " +
    "Bittet jemand darum, sag kurz und freundlich, dass das noch nicht geht und vielleicht später kommt. Gib dann auch keinen Code als Teilantwort. " +
    "Wenn du dir unsicher bist, sag es. " +
    (cat ? `Der Nutzer hat die Kategorie „${cat}“ gewählt; richte deine Antwort danach aus.` : "");

  // ---------- Panel auf/zu ----------
  const others = () => { $("#overlay").classList.remove("open"); $("#picker").classList.remove("open"); };
  const open = () => { others(); panel.classList.add("open"); setTimeout(() => ta.focus(), 50); };
  const close = () => panel.classList.remove("open");
  $("#aiBtn").addEventListener("click", () => (panel.classList.contains("open") ? close() : open()));
  $("#aiClose").addEventListener("click", close);
  $("#pen").addEventListener("click", close);           // Stift schließt die KI
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && panel.classList.contains("open")) close(); });

  // ---------- Darstellung ----------
  function bubble(kind, text, imgs) {
    const hello = log.querySelector(".ai-hello");
    if (hello) hello.remove();
    const d = document.createElement("div");
    d.className = "ai-msg " + kind;
    (imgs || []).forEach((u) => { const i = document.createElement("img"); i.src = u; i.alt = "Hochgeladenes Bild"; d.appendChild(i); });
    d.appendChild(document.createTextNode(text));
    log.appendChild(d);
    log.scrollTop = log.scrollHeight;
    return d;
  }
  function hello() {
    log.textContent = "";
    const h = document.createElement("div");
    h.className = "ai-hello";
    h.textContent = "Hallo! Ich beantworte dir Fragen und erkläre Bilder. Skripte und Programme kann ich noch nicht.";
    log.appendChild(h);
  }
  function renderHistory() {
    log.textContent = "";
    if (!state.history.length) { hello(); return; }
    state.history.forEach((m) => bubble(m.role === "user" ? "user" : "bot", (m.images ? `[${m.images} Bild${m.images > 1 ? "er" : ""}] ` : "") + m.text));
  }

  // ---------- Kategorien ----------
  const cats = $("#aiCats");
  CATS.forEach((c) => {
    const b = document.createElement("button");
    b.type = "button"; b.textContent = c; b.setAttribute("aria-pressed", "false");
    b.addEventListener("click", () => { state.cat = state.cat === c ? "" : c; markCats(); store.save(); });
    cats.appendChild(b);
  });
  function markCats() { [...cats.children].forEach((b) => b.setAttribute("aria-pressed", String(b.textContent === state.cat))); }

  // ---------- Bilder ----------
  $("#aiAttach").addEventListener("click", () => $("#aiFile").click());
  $("#aiFile").addEventListener("change", async (e) => {
    for (const f of [...e.target.files]) {
      if (pending.length >= MAX_IMAGES) break;
      if (!f.type.startsWith("image/")) continue;
      try { pending.push(await shrink(f)); } catch (_) {}
    }
    e.target.value = "";
    drawThumbs();
  });
  function shrink(file) {      // auf höchstens 1280 px verkleinern, als JPEG
    return new Promise((res, rej) => {
      const url = URL.createObjectURL(file), img = new Image();
      img.onload = () => {
        const k = Math.min(1, 1280 / Math.max(img.width, img.height));
        const c = document.createElement("canvas");
        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        const out = c.toDataURL("image/jpeg", 0.85);
        res({ data: out.split(",")[1], type: "image/jpeg", url: out });
      };
      img.onerror = () => { URL.revokeObjectURL(url); rej(); };
      img.src = url;
    });
  }
  function drawThumbs() {
    thumbs.textContent = "";
    pending.forEach((p, i) => {
      const t = document.createElement("div"); t.className = "ai-thumb"; t.style.backgroundImage = `url(${p.url})`;
      const x = document.createElement("button"); x.type = "button"; x.textContent = "✕"; x.setAttribute("aria-label", "Bild entfernen");
      x.addEventListener("click", () => { pending.splice(i, 1); drawThumbs(); });
      t.appendChild(x); thumbs.appendChild(t);
    });
  }

  // ---------- Einrichtung ----------
  $("#aiSetupBtn").addEventListener("click", () => { setup.hidden = !setup.hidden; if (!setup.hidden) $("#aiKey").value = state.key === DEFAULT_KEY ? "" : state.key; });
  $("#aiKeySave").addEventListener("click", () => {
    const v = $("#aiKey").value.trim(), m = $("#aiKeyMsg");
    if (!v) { state.key = DEFAULT_KEY; store.save(); m.className = "msg"; m.textContent = "Eigener Schlüssel entfernt, der eingebaute wird benutzt."; return; }
    state.key = v; store.save(); m.className = "msg"; m.textContent = "Gespeichert."; setup.hidden = true;
  });
  $("#aiClear").addEventListener("click", () => { if (busy) return; state.history = []; store.save(); renderHistory(); });

  // ---------- Senden ----------
  ta.addEventListener("input", () => { ta.style.height = "auto"; ta.style.height = Math.min(120, ta.scrollHeight) + "px"; });
  ta.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } });
  sendBtn.addEventListener("click", send);

  function apiMessages(newImgs, text) {
    const msgs = state.history.slice(-20).map((m) => ({ role: m.role, content: (m.images ? `[${m.images} Bild(er) wurden gesendet] ` : "") + m.text }));
    const content = newImgs.map((p) => ({ type: "image", source: { type: "base64", media_type: p.type, data: p.data } }));
    content.push({ type: "text", text: text || "Beschreibe und erkläre dieses Bild." });
    msgs.push({ role: "user", content });
    // Die API verlangt wechselnde Rollen; fehlerhafte Reste (z. B. zwei user-Nachrichten) zusammenführen
    const out = [];
    for (const m of msgs) {
      const last = out[out.length - 1];
      if (last && last.role === m.role) {
        const a = typeof last.content === "string" ? [{ type: "text", text: last.content }] : last.content;
        const b = typeof m.content === "string" ? [{ type: "text", text: m.content }] : m.content;
        last.content = a.concat(b);
      } else out.push(m);
    }
    if (out[0] && out[0].role !== "user") out.shift();
    return out;
  }

  // ---------- Zwei Anbieter: Google Gemini (kostenlos) oder Anthropic ----------
  const isAnthropic = () => state.key.startsWith("sk-ant-");
  const GEMINI_MODELS = ["gemini-flash-latest", "gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-flash-lite-latest"];

  async function callAnthropic(imgs, text) {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": state.key,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true"
      },
      body: JSON.stringify({ model: MODEL, max_tokens: 1024, system: SYSTEM(state.cat), messages: apiMessages(imgs, text) })
    });
    const j = await r.json().catch(() => ({}));
    const reply = (j.content || []).filter((c) => c.type === "text").map((c) => c.text).join("\n").trim();
    return { ok: r.ok, status: r.status, reply, j };
  }

  function geminiContents(imgs, text) {
    const turns = state.history.slice(-20).map((m) => ({
      role: m.role === "user" ? "user" : "model",
      parts: [{ text: (m.images ? `[${m.images} Bild(er) wurden gesendet] ` : "") + m.text }]
    }));
    const parts = imgs.map((p) => ({ inlineData: { mimeType: p.type, data: p.data } }));
    parts.push({ text: text || "Beschreibe und erkläre dieses Bild." });
    turns.push({ role: "user", parts });
    const out = [];                                   // Rollen müssen sich abwechseln
    for (const t of turns) {
      const last = out[out.length - 1];
      if (last && last.role === t.role) last.parts = last.parts.concat(t.parts); else out.push(t);
    }
    if (out[0] && out[0].role !== "user") out.shift();
    return out;
  }

  async function callGemini(imgs, text) {
    const body = JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM(state.cat) }] },
      contents: geminiContents(imgs, text),
      generationConfig: { maxOutputTokens: 1024 }
    });
    let res;
    for (const model of GEMINI_MODELS) {
      const own = !!state.key;                         // eigener Schlüssel: direkt zu Google, sonst über den Mini-Server
      const base = own ? "https://generativelanguage.googleapis.com" : WORKER_URL;
      const headers = { "content-type": "application/json" };
      if (own) headers["x-goog-api-key"] = state.key;
      const r = await fetch(`${base}/v1beta/models/${model}:generateContent`, { method: "POST", headers, body });
      const j = await r.json().catch(() => ({}));
      const c = j.candidates && j.candidates[0];
      const reply = c && c.content && c.content.parts ? c.content.parts.map((p) => p.text || "").join("\n").trim() : "";
      res = { ok: r.ok, status: r.status, j, reply, blocked: !!(j.promptFeedback && j.promptFeedback.blockReason) };
      if (![404, 429, 500, 503].includes(r.status)) break;   // Modell unbekannt oder überlastet: nächstes probieren
      await new Promise((ok) => setTimeout(ok, 600));
    }
    return res;
  }

  function errorText(r) {
    const msg = (r.j && r.j.error && r.j.error.message) || "unbekannt";
    if (r.status === 401 || r.status === 403 || (r.status === 400 && /api key/i.test(msg))) return "Der API-Schlüssel ist ungültig. Prüfe ihn unter ⚙ (oder leer lassen, um den Standard zu nutzen).";
    if (r.status === 429) return "Das kostenlose Limit ist gerade erreicht. Warte kurz und versuche es noch einmal.";
    if (r.status === 503 || r.status === 500) return "Google ist gerade überlastet. Versuch es in ein paar Sekunden noch einmal.";
    if (/credit|balance/i.test(msg)) return "Auf dem API-Konto ist kein Guthaben mehr.";
    return `Fehler ${r.status}: ${msg}`;
  }

  async function send() {
    if (busy) return;
    const text = ta.value.trim();
    if (!text && !pending.length) return;
    
    const imgs = pending; pending = []; drawThumbs();
    ta.value = ""; ta.style.height = "auto";
    bubble("user", text, imgs.map((p) => p.url));
    const wait = bubble("bot wait", "Die KI denkt nach …");
    busy = true; sendBtn.disabled = true;
    try {
      const r = await (isAnthropic() ? callAnthropic(imgs, text) : callGemini(imgs, text));
      if (!r.ok) {
        wait.className = "ai-msg err"; wait.textContent = errorText(r);
      } else if (!r.reply) {
        wait.className = "ai-msg err"; wait.textContent = r.blocked ? "Diese Frage kann die KI nicht beantworten." : "Die KI hat nichts geantwortet. Versuch es noch einmal.";
      } else {
        wait.className = "ai-msg bot"; wait.textContent = r.reply;
        state.history.push({ role: "user", text: text || "(Bild)", images: imgs.length }, { role: "assistant", text: r.reply, images: 0 });
        store.save();
      }
    } catch (_) {
      wait.className = "ai-msg err"; wait.textContent = "Keine Verbindung zur KI. Prüfe dein Internet.";
    }
    busy = false; sendBtn.disabled = false; log.scrollTop = log.scrollHeight; ta.focus();
  }

  // Der Stift-Klick der Haupt-Datei schaltet #overlay um; wenn die KI offen ist, darf sie nicht dahinter liegen bleiben (siehe close oben).
  store.load((s) => { state.key = s.key || DEFAULT_KEY; state.cat = s.cat || ""; state.history = s.history || []; markCats(); renderHistory(); });
})();
