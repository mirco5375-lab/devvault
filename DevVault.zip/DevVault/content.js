(() => {
  const KEY = "gbg_settings";
  const DEFAULTS = { image: "", barColor: "#ffffff", barOpacity: 0 };
  let settings = Object.assign({}, DEFAULTS);

  // ---------- Styles auf der Google-Seite ----------
  const pageStyle = document.createElement("style");
  pageStyle.id = "gbg-page-style";
  document.documentElement.appendChild(pageStyle);

  function hexToRgba(hex, a) {
    const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex) || [];
    const r = parseInt(m[1] || "ff", 16), g = parseInt(m[2] || "ff", 16), b = parseInt(m[3] || "ff", 16);
    return `rgba(${r}, ${g}, ${b}, ${a})`;
  }

  function applyStyles() {
    let css = "";
    if (settings.image) {
      css += `
        html {
          background: url("${settings.image}") center / cover no-repeat fixed !important;
        }
        body, #main, #viewport, .L3eUgb, .o3j99, .RNNXgb, .minidiv, .sfbg {
          background: transparent !important;
        }
      `;
    }
    // Obere Leiste: Farbe + Deckkraft (0 = komplett unsichtbar)
    const bar = hexToRgba(settings.barColor, settings.barOpacity / 100);
    css += `
      #gb, header, [role="banner"], .gb_Pd, .gb_Ld, .Fgvgjc, .sfbg, #searchform,
      #searchform > div, .logo, .o3j99.n1xJcf, .o3j99.LLD4me {
        background: ${bar} !important;
        box-shadow: none !important;
        border-bottom: 0 !important;
      }
    `;
    pageStyle.textContent = css;
  }

  function save() {
    chrome.storage.local.set({ [KEY]: settings });
  }

  // ---------- Stift-Button + Einstellungs-Frame (Shadow DOM) ----------
  function buildUI() {
    const host = document.createElement("div");
    host.id = "gbg-host";
    host.style.cssText = "position:fixed;top:12px;right:12px;z-index:2147483647;";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
      <style>
        * { box-sizing: border-box; font-family: system-ui, Arial, sans-serif; }
        .pen {
          width: 40px; height: 40px; border-radius: 50%; border: 0; cursor: pointer;
          background: rgba(255,255,255,.75); backdrop-filter: blur(6px);
          font-size: 20px; box-shadow: 0 2px 8px rgba(0,0,0,.3);
        }
        .pen:hover { background: #fff; }
        .overlay {
          display: none; position: fixed; inset: 0; background: rgba(0,0,0,.45);
          align-items: center; justify-content: center;
        }
        .overlay.open { display: flex; }
        .card {
          width: 380px; max-width: 92vw; max-height: 90vh; overflow: auto;
          background: #fff; color: #202124; border-radius: 14px; padding: 20px;
          box-shadow: 0 10px 40px rgba(0,0,0,.4);
        }
        .head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
        h3 { margin: 0; font-size: 18px; }
        .close { border: 0; background: none; font-size: 20px; cursor: pointer; }
        h4 { margin: 18px 0 6px; font-size: 14px; }
        input[type=text] { width: 100%; padding: 7px; border: 1px solid #ccc; border-radius: 6px; }
        input[type=range] { width: 100%; }
        .row { display: flex; align-items: center; gap: 10px; margin-top: 8px; font-size: 13px; }
        .row input[type=color] { width: 44px; height: 30px; padding: 0; border: 1px solid #ccc; border-radius: 6px; }
        button.btn {
          margin-top: 10px; padding: 8px 14px; border: 0; border-radius: 6px;
          background: #1a73e8; color: #fff; cursor: pointer; font-size: 13px;
        }
        button.btn.gray { background: #e8eaed; color: #202124; }
        .preview { margin-top: 10px; height: 90px; border-radius: 8px; background: #eee center/cover no-repeat; }
      </style>
      <button class="pen" title="Google anpassen">✏️</button>
      <div class="overlay">
        <div class="card">
          <div class="head"><h3>Google anpassen</h3><button class="close" title="Schließen">✕</button></div>

          <h4>Obere Leiste</h4>
          <div class="row"><span>Farbe</span><input type="color" id="barColor"></div>
          <div class="row"><span>Sichtbarkeit</span><input type="range" id="barOpacity" min="0" max="100"><span id="barVal"></span></div>
          <div style="font-size:12px;color:#5f6368;margin-top:4px">0 % = komplett unsichtbar</div>

          <h4>Hintergrundbild</h4>
          <button class="btn" id="pick">Datei hochladen</button>
          <input type="file" id="file" accept="image/*" style="display:none">
          <div class="row"><input type="text" id="url" placeholder="oder Bild-URL einfügen"></div>
          <button class="btn gray" id="useUrl">URL übernehmen</button>
          <div class="preview" id="preview"></div>

          <button class="btn gray" id="reset" style="margin-top:16px">Alles zurücksetzen</button>
        </div>
      </div>
    `;
    const $ = (s) => root.querySelector(s);
    const overlay = $(".overlay");

    function refresh() {
      $("#barColor").value = settings.barColor;
      $("#barOpacity").value = settings.barOpacity;
      $("#barVal").textContent = settings.barOpacity + " %";
      $("#preview").style.backgroundImage = settings.image ? `url("${settings.image}")` : "none";
    }

    $(".pen").addEventListener("click", () => overlay.classList.add("open"));
    $(".close").addEventListener("click", () => overlay.classList.remove("open"));
    overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.classList.remove("open"); });

    $("#barColor").addEventListener("input", (e) => { settings.barColor = e.target.value; save(); applyStyles(); });
    $("#barOpacity").addEventListener("input", (e) => {
      settings.barOpacity = Number(e.target.value);
      $("#barVal").textContent = settings.barOpacity + " %";
      save(); applyStyles();
    });

    $("#pick").addEventListener("click", () => $("#file").click());
    $("#file").addEventListener("change", (e) => {
      const f = e.target.files[0];
      if (!f) return;
      const img = new Image();
      img.onload = () => {
        const max = 2560;
        const scale = Math.min(1, max / img.width);
        const c = document.createElement("canvas");
        c.width = Math.round(img.width * scale);
        c.height = Math.round(img.height * scale);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        settings.image = c.toDataURL("image/jpeg", 0.88);
        URL.revokeObjectURL(img.src);
        save(); applyStyles(); refresh();
      };
      img.src = URL.createObjectURL(f);
    });

    $("#useUrl").addEventListener("click", () => {
      const v = $("#url").value.trim();
      if (!v) return;
      settings.image = v;
      save(); applyStyles(); refresh();
    });

    $("#reset").addEventListener("click", () => {
      settings = Object.assign({}, DEFAULTS);
      save(); applyStyles(); refresh();
    });

    document.documentElement.appendChild(host);
    refresh();
  }

  // ---------- Start ----------
  chrome.storage.local.get(KEY, (res) => {
    if (res[KEY]) settings = Object.assign(settings, res[KEY]);
    applyStyles();
    buildUI();
  });
})();
