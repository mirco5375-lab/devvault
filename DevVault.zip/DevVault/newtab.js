const KEY = "gbg_settings";
const TITLE = "DevVault";                 // fester Titel, nicht änderbar
const MAX_VIDEO_SECONDS = 600;            // Videos dürfen höchstens so lang sein (10 Minuten)
const MAX_VIDEO_BYTES = 500 * 1024 * 1024; // und höchstens so groß (500 MB)

// 90 -> "1 min 30 s", 4.2 -> "4.2 s"
function fmtDur(s) {
  if (s < 60) return s.toFixed(1) + " s";
  const m = Math.floor(s / 60);
  const r = Math.round(s - m * 60);
  return r === 60 ? `${m + 1} min` : `${m} min ${r} s`;
}

const DEFAULTS = {
  image: "", barColor: "#ffffff", barOpacity: 0, searchOpacity: 15,
  font: "", fontCustom: "", hasVideo: false, dismissedUpdate: ""
};

// x/y = Mitte des Elements als Anteil der Fensterbreite/-höhe (0 bis 1), scale = Größe in Prozent
const LAYOUT_DEFAULTS = {
  title:  { x: 0.50, y: 0.465, scale: 100, color: "#ffffff" },
  search: { x: 0.50, y: 0.565, scale: 100 }
};
const LOOK = { scale: 100, color: "#ffffff", bg: "#141418", bgOpacity: 42 };
const WIDGET_DEFAULTS = {
  clock:   Object.assign({ on: false, x: 0.27, y: 0.20, seconds: false, h12: false, tz: "", city: "" }, LOOK),
  date:    Object.assign({ on: false, x: 0.27, y: 0.34, tz: "", city: "" }, LOOK),
  weather: Object.assign({ on: false, x: 0.87, y: 0.20, city: "", lat: null, lon: null, unit: "c" }, LOOK),
  notes:   Object.assign({ on: false, x: 0.87, y: 0.52, text: "" }, LOOK),
  timer:   Object.assign({ on: false, x: 0.27, y: 0.52, minutes: 5 }, LOOK),
  apps:    Object.assign({ on: true,  x: 0.50, y: 0.72 }, LOOK, { bgOpacity: 0 })
};
const STATIC = { title: "#title", search: "#searchbox" }; // feste, aber verschiebbare Elemente

function mergeSettings(saved) {
  saved = saved || {};
  const s = Object.assign({}, DEFAULTS, saved);
  const sw = saved.widgets || {};
  const sl = saved.layout || {};
  s.widgets = {};
  for (const id of Object.keys(WIDGET_DEFAULTS)) s.widgets[id] = Object.assign({}, WIDGET_DEFAULTS[id], sw[id]);
  s.layout = {};
  for (const id of Object.keys(LAYOUT_DEFAULTS)) s.layout[id] = Object.assign({}, LAYOUT_DEFAULTS[id], sl[id]);
  return s;
}

let settings = mergeSettings();
const $ = (s) => document.querySelector(s);
const el = (tag, cls, text) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
};

// ---------- Update-Meldungen ----------
// Neues Update: Version in manifest.json erhöhen und hier einen Eintrag mit der gleichen
// Versionsnummer ergänzen. Die Meldung erscheint dann einmal wieder, bis man
// "Nicht mehr erneut anzeigen" klickt.
const CHANGELOG = {
  "1.3": [
    "Der Titel „DevVault“ ist jetzt fest und lässt sich nicht mehr ändern.",
    "Neu: Die Schriftart der ganzen Seite kannst du in den Einstellungen wählen.",
    "Neu: Videos als Hintergrund (höchstens 4 Sekunden, Schleife, ohne Ton)."
  ],
  "1.4": [
    "Neu: Widgets! Stift öffnen, ganz unten auf das Plus drücken und Widgets auswählen.",
    "Mit dabei: Uhr, Datum, Wetter, Apps (deine meistbesuchten Seiten), Notizen und Timer.",
    "Verschieben geht am Griff ⠿ oben links am Widget, entfernen mit dem ✕ oben rechts."
  ],
  "1.5": [
    "Alles lässt sich verschieben: Widgets, der Titel „DevVault“ und das Suchfeld.",
    "Der Anpass-Frame sitzt jetzt links in der Mitte und ist dunkel.",
    "Bei jedem Widget kannst du Größe und Farben einstellen, auch beim Titel und beim Suchfeld.",
    "Uhr, Datum und Wetter: Du kannst einstellen, für welchen Ort sie gelten."
  ],
  "1.6": [
    "Videos als Hintergrund dürfen jetzt viel länger sein: bis 10 Minuten und 500 MB (vorher 4 Sekunden)."
  ],
  "1.7": [
    "Neu: KI-Assistent! Das Funkel-Symbol neben dem Stift öffnet den Chat links in der Mitte.",
    "Unten stellst du Fragen, lädst Bilder hoch und wählst eine Kategorie.",
    "Die KI schreibt keine Skripte und keine Programme. Beim ersten Mal trägst du unter ⚙ deinen API-Schlüssel ein."
  ],
  "1.8": [
    "Die KI läuft jetzt auch kostenlos: Hol dir unter aistudio.google.com/apikey einen Gratis-Schlüssel (ohne Kreditkarte) und trage ihn im KI-Fenster unter ⚙ ein."
  ]
};

function showUpdate() {
  const v = chrome.runtime.getManifest().version;
  const notes = CHANGELOG[v];
  if (!notes || settings.dismissedUpdate === v) return;
  $("#updTitle").textContent = `Neu in Version ${v}`;
  const list = $("#updList");
  list.textContent = "";
  notes.forEach((t) => list.appendChild(el("li", null, t)));
  $("#update").hidden = false;
}
$("#updOk").addEventListener("click", () => { $("#update").hidden = true; });
$("#updNever").addEventListener("click", () => {
  settings.dismissedUpdate = chrome.runtime.getManifest().version;
  save();
  $("#update").hidden = true;
});

// ---------- Hilfsfunktionen ----------
function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex) || [];
  return [parseInt(m[1] || "ff", 16), parseInt(m[2] || "ff", 16), parseInt(m[3] || "ff", 16)];
}

function save() {
  clearTimeout(saveTimer);
  chrome.storage.local.set({ [KEY]: settings });
}
let saveTimer = null;
function saveSoon() {          // für Regler und Farbwähler: nicht bei jedem Pixel speichern
  clearTimeout(saveTimer);
  saveTimer = setTimeout(save, 400);
}

function message(text, isError) {
  const m = $("#msg");
  m.textContent = text || "";
  m.className = "msg" + (isError ? " err" : "");
}

// ---------- Schriftarten ----------
const FONTS = [
  ["Standard", ""],
  ["Arial", "Arial, sans-serif"],
  ["Verdana", "Verdana, sans-serif"],
  ["Trebuchet MS", '"Trebuchet MS", sans-serif'],
  ["Tahoma", "Tahoma, sans-serif"],
  ["Georgia (Serif)", "Georgia, serif"],
  ["Times New Roman", '"Times New Roman", serif'],
  ["Palatino", '"Palatino Linotype", Palatino, serif'],
  ["Courier New (Schreibmaschine)", '"Courier New", monospace'],
  ["Consolas (Code)", "Consolas, monospace"],
  ["Impact", "Impact, sans-serif"],
  ["Comic Sans MS", '"Comic Sans MS", cursive'],
  ["Segoe Script (Handschrift)", '"Segoe Script", "Brush Script MT", cursive']
];
FONTS.forEach(([name, value]) => {
  const o = el("option", null, name);
  o.value = value;
  if (value) o.style.fontFamily = value;
  $("#font").appendChild(o);
});

// ---------- Video-Speicher (IndexedDB) ----------
function dbOpen() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("gbg", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("files");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function dbRun(mode, fn) {
  const db = await dbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("files", mode);
    const req = fn(tx.objectStore("files"));
    tx.oncomplete = () => { db.close(); resolve(req && req.result); };
    tx.onerror = () => { db.close(); reject(tx.error); };
    tx.onabort = () => { db.close(); reject(tx.error); };
  });
}
const dbPut = (key, value) => dbRun("readwrite", (s) => s.put(value, key));
const dbGet = (key) => dbRun("readonly", (s) => s.get(key));
const dbDelete = (key) => dbRun("readwrite", (s) => s.delete(key));

let videoOn = false;
let videoUrl = "";

function showVideoBlob(blob) {
  if (videoUrl) URL.revokeObjectURL(videoUrl);
  videoUrl = URL.createObjectURL(blob);
  const v = $("#bgVideo");
  v.src = videoUrl;
  v.classList.add("on");
  const p = v.play();
  if (p && p.catch) p.catch(() => {});
  videoOn = true;
}

function hideVideo() {
  const v = $("#bgVideo");
  v.classList.remove("on");
  v.removeAttribute("src");
  if (videoUrl) { URL.revokeObjectURL(videoUrl); videoUrl = ""; }
  videoOn = false;
}

async function loadSavedVideo() {
  if (!settings.hasVideo) return;
  try {
    const blob = await dbGet("video");
    if (blob) { showVideoBlob(blob); apply(); }
  } catch (e) { /* ohne Video weiter */ }
}

async function clearVideo() {
  try { await dbDelete("video"); } catch (e) { /* egal */ }
  settings.hasVideo = false;
  hideVideo();
}

// ---------- Hintergrund ----------
// wallpaper.jpg wird vom Design-Generator (design_erstellen.py) angelegt.
// Es ist so ausgerichtet, dass das Bild nahtlos hinter Tabs und Adressleiste weitergeht.
let wallpaperOk = false;
const probe = new Image();
probe.onload = () => { wallpaperOk = true; apply(); };
probe.src = "wallpaper.jpg";

function applyBackground() {
  const b = document.body.style;
  if (videoOn) {
    b.backgroundImage = "";
  } else if (settings.image) {
    b.backgroundImage = `url("${settings.image}")`;
    b.backgroundSize = "cover";
    b.backgroundPosition = "center";
  } else if (wallpaperOk) {
    const off = Math.max(0, window.outerHeight - window.innerHeight);
    b.backgroundImage = 'url("wallpaper.jpg")';
    b.backgroundSize = `${screen.width}px ${screen.height}px`;
    b.backgroundPosition = `0 -${off}px`;
    b.backgroundRepeat = "no-repeat";
  } else {
    b.backgroundImage = "";
  }
}
window.addEventListener("resize", applyBackground);

// ---------- Position, Größe und Farben eines Elements ----------
function boxOf(id) {
  if (STATIC[id]) return { cfg: settings.layout[id], root: $(STATIC[id]) };
  return { cfg: settings.widgets[id], root: mounted[id] && mounted[id].root };
}

function styleBox(id) {
  const { cfg, root } = boxOf(id);
  if (!root) return;
  root.style.left = (cfg.x * 100) + "%";
  root.style.top = (cfg.y * 100) + "%";
  root.style.transform = `translate(-50%, -50%) scale(${(cfg.scale || 100) / 100})`;
  if (cfg.color) {
    root.style.color = cfg.color;
    const [r, g, b] = hexToRgb(cfg.color);
    root.style.textShadow = 0.299 * r + 0.587 * g + 0.114 * b > 150 ? "0 1px 4px rgba(0,0,0,.5)" : "none";
  }
  if (cfg.bg !== undefined) {
    const [r, g, b] = hexToRgb(cfg.bg);
    const a = (cfg.bgOpacity || 0) / 100;
    root.style.background = a > 0 ? `rgba(${r}, ${g}, ${b}, ${a})` : "none";
    root.style.backdropFilter = a > 0 ? "blur(10px)" : "none";
    root.style.boxShadow = a > 0 ? "0 4px 18px rgba(0,0,0,.3)" : "none";
  }
}

function apply() {
  applyBackground();

  // Obere Leiste
  const [r, g, b] = hexToRgb(settings.barColor);
  const bar = $("#bar");
  bar.style.background = `rgba(${r}, ${g}, ${b}, ${settings.barOpacity / 100})`;
  const lum = 0.299 * r + 0.587 * g + 0.114 * b;
  bar.style.color = settings.barOpacity >= 50 && lum > 150 ? "#202124" : "#fff";
  $("#barColor").value = settings.barColor;
  $("#barOpacity").value = settings.barOpacity;
  $("#barVal").textContent = settings.barOpacity + " %";

  // Fester Titel (verschiebbar, Größe und Farbe einstellbar)
  $("#logo").textContent = TITLE;
  document.title = "Neuer Tab";
  const lt = settings.layout.title, ls = settings.layout.search;
  $("#titleScale").value = lt.scale;
  $("#titleScaleVal").textContent = lt.scale + " %";
  $("#titleColor").value = lt.color;
  $("#searchScale").value = ls.scale;
  $("#searchScaleVal").textContent = ls.scale + " %";
  styleBox("title");
  styleBox("search");

  // Durchsichtiges Suchfeld
  const q = $("#q");
  q.style.setProperty("--so", settings.searchOpacity / 100);
  const solid = settings.searchOpacity >= 60;
  q.style.color = solid ? "#202124" : "#fff";
  q.classList.toggle("solid", solid);
  $("#searchOpacity").value = settings.searchOpacity;
  $("#searchVal").textContent = settings.searchOpacity + " %";

  // Schriftart der ganzen Seite (gilt auch für die Widgets)
  const custom = String(settings.fontCustom || "").replace(/["';{}<>\\]/g, "").trim();
  document.body.style.fontFamily = custom ? `"${custom}", sans-serif` : settings.font;
  $("#font").value = settings.font;
  if ($("#fontCustom").value !== settings.fontCustom) $("#fontCustom").value = settings.fontCustom;

  $("#vidState").textContent = videoOn ? "Video-Hintergrund ist aktiv. Ein neues Bild oder Video ersetzt es." : "";
  $("#preview").style.backgroundImage = settings.image ? `url("${settings.image}")` : "none";
}

// ---------- Suche ----------
$("#search").addEventListener("submit", (e) => {
  const v = $("#q").value.trim();
  if (!v) { e.preventDefault(); return; }
  if (/^(https?:\/\/)?[\w-]+(\.[\w-]+)+(:\d+)?(\/\S*)?$/i.test(v)) {
    e.preventDefault();
    location.href = /^https?:\/\//i.test(v) ? v : "https://" + v;
  }
});

// =====================================================================
// Orte (Geocoding + Standort)
// =====================================================================
const round2 = (n) => Math.round(n * 100) / 100;

function validTz(tz) {
  if (!tz) return false;
  try { new Intl.DateTimeFormat("de-DE", { timeZone: tz }); return true; } catch (e) { return false; }
}

async function geocode(name) {
  const u = new URL("https://geocoding-api.open-meteo.com/v1/search");
  u.searchParams.set("name", name);
  u.searchParams.set("count", "1");
  u.searchParams.set("language", "de");
  u.searchParams.set("format", "json");
  const r = await fetch(u);
  if (!r.ok) throw new Error("HTTP " + r.status);
  const j = await r.json();
  const p = j.results && j.results[0];
  if (!p) return null;
  return {
    city: p.country ? `${p.name}, ${p.country}` : p.name,
    lat: p.latitude, lon: p.longitude, tz: p.timezone || ""
  };
}

function whereAmI() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) { reject(new Error("no geolocation")); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: round2(pos.coords.latitude), lon: round2(pos.coords.longitude) }),
      reject, { timeout: 10000 }
    );
  });
}

// =====================================================================
// Widgets
// =====================================================================

// Wettercodes (WMO) -> Symbol und Text
function wmo(code) {
  if (code === 0) return ["☀️", "Klar"];
  if (code === 1) return ["🌤️", "Überwiegend klar"];
  if (code === 2) return ["⛅", "Teils bewölkt"];
  if (code === 3) return ["☁️", "Bedeckt"];
  if (code === 45 || code === 48) return ["🌫️", "Nebel"];
  if (code >= 51 && code <= 55) return ["🌦️", "Nieselregen"];
  if (code === 56 || code === 57) return ["🌧️", "Gefrierender Nieselregen"];
  if (code >= 61 && code <= 65) return ["🌧️", "Regen"];
  if (code === 66 || code === 67) return ["🌧️", "Gefrierender Regen"];
  if (code >= 71 && code <= 75) return ["❄️", "Schneefall"];
  if (code === 77) return ["❄️", "Schneegriesel"];
  if (code >= 80 && code <= 82) return ["🌦️", "Regenschauer"];
  if (code === 85 || code === 86) return ["🌨️", "Schneeschauer"];
  if (code >= 95) return ["⛈️", "Gewitter"];
  return ["🌡️", "Unbekannt"];
}

function startClock(body, cfg) {
  const t = el("div", "w-time");
  body.appendChild(t);
  if (cfg.city) body.appendChild(el("div", "w-place", cfg.city));
  const tick = () => {
    const opts = { hour: "2-digit", minute: "2-digit", hour12: !!cfg.h12 };
    if (cfg.seconds) opts.second = "2-digit";
    if (validTz(cfg.tz)) opts.timeZone = cfg.tz;
    t.textContent = new Date().toLocaleTimeString("de-DE", opts);
  };
  tick();
  const id = setInterval(tick, 1000);
  return () => clearInterval(id);
}

function startDate(body, cfg) {
  const t = el("div", "w-date");
  body.appendChild(t);
  if (cfg.city) body.appendChild(el("div", "w-place", cfg.city));
  const tick = () => {
    const opts = { weekday: "long", day: "numeric", month: "long", year: "numeric" };
    if (validTz(cfg.tz)) opts.timeZone = cfg.tz;
    t.textContent = new Date().toLocaleDateString("de-DE", opts);
  };
  tick();
  const id = setInterval(tick, 30000);
  return () => clearInterval(id);
}

function startWeather(body, cfg) {
  const wrap = el("div", "w-weather");
  const icon = el("div", "w-wicon", "🌡️");
  const txt = el("div", "txt");
  const temp = el("div", "w-wtemp", "–");
  const desc = el("div", "w-wdesc", "");
  const place = el("div", "w-wplace", "");
  txt.append(temp, desc, place);
  wrap.append(icon, txt);
  body.appendChild(wrap);

  if (cfg.lat == null || cfg.lon == null) {
    desc.textContent = "Ort wählen:";
    place.textContent = "Stift → ＋ → Wetter";
    return null;
  }
  place.textContent = cfg.city || "Mein Standort";
  desc.textContent = "lädt …";

  let alive = true;
  async function load() {
    try {
      const u = new URL("https://api.open-meteo.com/v1/forecast");
      u.searchParams.set("latitude", cfg.lat);
      u.searchParams.set("longitude", cfg.lon);
      u.searchParams.set("current", "temperature_2m,apparent_temperature,weather_code,wind_speed_10m");
      u.searchParams.set("temperature_unit", cfg.unit === "f" ? "fahrenheit" : "celsius");
      u.searchParams.set("timezone", "auto");
      const r = await fetch(u);
      if (!r.ok) throw new Error("HTTP " + r.status);
      const j = await r.json();
      if (!alive) return;
      const c = j.current;
      const [ic, label] = wmo(c.weather_code);
      icon.textContent = ic;
      temp.textContent = Math.round(c.temperature_2m) + (cfg.unit === "f" ? " °F" : " °C");
      desc.textContent = `${label} · gefühlt ${Math.round(c.apparent_temperature)}°`;
    } catch (e) {
      if (alive) desc.textContent = "Wetter nicht erreichbar";
    }
  }
  load();
  const id = setInterval(load, 15 * 60 * 1000);
  return () => { alive = false; clearInterval(id); };
}

function faviconUrl(pageUrl) {
  return chrome.runtime.getURL("/_favicon/") + "?pageUrl=" + encodeURIComponent(pageUrl) + "&size=32";
}

function startApps(body) {
  const grid = el("div", "tiles");
  body.appendChild(grid);
  if (!chrome.topSites) return null;
  chrome.topSites.get((sites) => {
    (sites || []).slice(0, 10).forEach((s) => {
      const a = el("a", "tile");
      a.href = s.url;
      const ico = el("div", "ico");
      const img = el("img");
      img.src = faviconUrl(s.url);
      img.alt = "";
      ico.appendChild(img);
      let label = s.title;
      if (!label) { try { label = new URL(s.url).hostname; } catch (e) { label = s.url; } }
      a.append(ico, el("span", null, label));
      grid.appendChild(a);
    });
  });
  return null;
}

function startNotes(body, cfg) {
  const wrap = el("div", "w-notes");
  const ta = el("textarea");
  ta.placeholder = "Notizen …";
  ta.value = cfg.text || "";
  ta.addEventListener("input", () => { cfg.text = ta.value; saveSoon(); });
  wrap.appendChild(ta);
  body.appendChild(wrap);
  return null;
}

function beep() {
  try {
    const A = window.AudioContext || window.webkitAudioContext;
    const ctx = new A();
    [0, 0.35, 0.7].forEach((d) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = 880;
      o.connect(g);
      g.connect(ctx.destination);
      g.gain.setValueAtTime(0.2, ctx.currentTime + d);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + d + 0.25);
      o.start(ctx.currentTime + d);
      o.stop(ctx.currentTime + d + 0.3);
    });
    setTimeout(() => { if (ctx.close) ctx.close(); }, 1500);
  } catch (e) { /* kein Ton möglich */ }
}

function startTimer(body, cfg) {
  const wrap = el("div", "w-timer");
  const t = el("div", "t");
  const btns = el("div", "btns");
  const go = el("button", null, "Start");
  const rs = el("button", null, "Zurück");
  btns.append(go, rs);
  wrap.append(t, btns);
  body.appendChild(wrap);

  const total = () => Math.max(1, Math.min(180, Number(cfg.minutes) || 5)) * 60;
  let left = total();
  let end = 0;
  let iv = null;
  const two = (n) => String(n).padStart(2, "0");
  const show = () => {
    const s = Math.max(0, Math.ceil(left));
    t.textContent = two(Math.floor(s / 60)) + ":" + two(s % 60);
  };
  function halt() {
    if (iv) { clearInterval(iv); iv = null; }
    go.textContent = "Start";
  }
  function tick() {
    left = (end - Date.now()) / 1000;
    if (left <= 0) {
      left = 0;
      halt();
      show();
      t.classList.add("done");
      beep();
      return;
    }
    show();
  }
  go.addEventListener("click", () => {
    if (iv) { left = (end - Date.now()) / 1000; halt(); show(); return; } // Pause
    if (left <= 0) left = total();
    t.classList.remove("done");
    end = Date.now() + left * 1000;
    iv = setInterval(tick, 200);
    go.textContent = "Pause";
  });
  rs.addEventListener("click", () => {
    halt();
    left = total();
    t.classList.remove("done");
    show();
  });
  show();
  return halt;
}

const WIDGETS = {
  clock:   { name: "Uhr",     icon: "🕒", desc: "Zeigt die Uhrzeit, auch für einen anderen Ort.", start: startClock },
  date:    { name: "Datum",   icon: "📅", desc: "Wochentag und Datum.",                          start: startDate },
  weather: { name: "Wetter",  icon: "🌤️", desc: "Wie warm es gerade an deinem Ort ist.",         start: startWeather },
  apps:    { name: "Apps",    icon: "🔲", desc: "Deine meistbesuchten Seiten als Symbole.",      start: startApps },
  notes:   { name: "Notizen", icon: "📝", desc: "Ein kleiner Notizzettel, der gespeichert wird.", start: startNotes },
  timer:   { name: "Timer",   icon: "⏱️", desc: "Countdown mit Signalton.",                     start: startTimer }
};

const mounted = {}; // id -> { root, body, stop }

function startBody(id) {
  const m = mounted[id];
  if (!m) return;
  if (m.stop) { try { m.stop(); } catch (e) { /* egal */ } m.stop = null; }
  m.body.textContent = "";
  const stop = WIDGETS[id].start(m.body, settings.widgets[id]);
  m.stop = typeof stop === "function" ? stop : null;
}

// Verschieben: gilt für Widgets, Titel und Suchfeld
function enableDrag(id, grip) {
  grip.addEventListener("pointerdown", (e) => {
    if (e.button !== undefined && e.button !== 0) return;
    e.preventDefault();
    const { cfg, root } = boxOf(id);
    const sx = e.clientX, sy = e.clientY;
    const ox = cfg.x * window.innerWidth, oy = cfg.y * window.innerHeight;
    root.classList.add("dragging");
    if (grip.setPointerCapture && e.pointerId !== undefined) {
      try { grip.setPointerCapture(e.pointerId); } catch (_) { /* egal */ }
    }
    const move = (ev) => {
      cfg.x = Math.min(0.97, Math.max(0.03, (ox + ev.clientX - sx) / window.innerWidth));
      cfg.y = Math.min(0.97, Math.max(0.08, (oy + ev.clientY - sy) / window.innerHeight));
      styleBox(id);
    };
    const up = () => {
      grip.removeEventListener("pointermove", move);
      grip.removeEventListener("pointerup", up);
      grip.removeEventListener("pointercancel", up);
      root.classList.remove("dragging");
      save();
    };
    grip.addEventListener("pointermove", move);
    grip.addEventListener("pointerup", up);
    grip.addEventListener("pointercancel", up);
  });
}

function mountWidget(id) {
  if (mounted[id]) return;
  const root = el("div", "widget");
  root.dataset.id = id;
  const grip = el("button", "ctl grip", "⠿");
  grip.title = "Verschieben";
  const del = el("button", "ctl del", "✕");
  del.title = "Entfernen";
  const body = el("div", "wbody");
  root.append(grip, del, body);
  $("#widgets").appendChild(root);
  mounted[id] = { root, body, stop: null };
  styleBox(id);
  startBody(id);
  del.addEventListener("click", () => {
    settings.widgets[id].on = false;
    save(); syncWidgets(); renderPicker();
  });
  enableDrag(id, grip);
}

function unmountWidget(id) {
  const m = mounted[id];
  if (!m) return;
  if (m.stop) { try { m.stop(); } catch (e) { /* egal */ } }
  m.root.remove();
  delete mounted[id];
}

function syncWidgets() {
  for (const id of Object.keys(WIDGETS)) {
    const on = settings.widgets[id].on;
    if (on && !mounted[id]) mountWidget(id);
    if (!on && mounted[id]) unmountWidget(id);
  }
}

// ---------- Widget-Auswahl (Plus) ----------
const picker = $("#picker");

function checkbox(label, checked, onChange) {
  const l = el("label");
  const c = el("input");
  c.type = "checkbox";
  c.checked = checked;
  c.addEventListener("change", () => onChange(c.checked));
  l.append(c, document.createTextNode(label));
  return l;
}

function rangeRow(label, min, max, value, onInput) {
  const row = el("div", "row");
  row.appendChild(el("span", "lbl", label));
  const r = el("input");
  r.type = "range"; r.min = min; r.max = max; r.value = value;
  const val = el("span", "val", value + " %");
  r.addEventListener("input", () => { val.textContent = r.value + " %"; onInput(Number(r.value)); });
  row.append(r, val);
  return { row, set: (v) => { r.value = v; val.textContent = v + " %"; } };
}

function colorRow(label, value, onInput) {
  const row = el("div", "row");
  row.appendChild(el("span", "lbl", label));
  const c = el("input");
  c.type = "color"; c.value = value;
  c.addEventListener("input", () => onInput(c.value));
  row.appendChild(c);
  return { row, set: (v) => { c.value = v; } };
}

// Größe und Farben eines Widgets
function lookOptions(id, cfg) {
  const d = el("details", "look");
  d.appendChild(el("summary", null, "Größe und Farbe"));
  const size = rangeRow("Größe", 50, 250, cfg.scale, (v) => { cfg.scale = v; saveSoon(); styleBox(id); });
  const col = colorRow("Schriftfarbe", cfg.color, (v) => { cfg.color = v; saveSoon(); styleBox(id); });
  const bg = colorRow("Hintergrund", cfg.bg, (v) => { cfg.bg = v; saveSoon(); styleBox(id); });
  const bgo = rangeRow("Sichtbarkeit", 0, 100, cfg.bgOpacity, (v) => { cfg.bgOpacity = v; saveSoon(); styleBox(id); });
  const rs = el("button", "btn gray small", "Aussehen zurücksetzen");
  rs.addEventListener("click", () => {
    const def = WIDGET_DEFAULTS[id];
    cfg.scale = def.scale; cfg.color = def.color; cfg.bg = def.bg; cfg.bgOpacity = def.bgOpacity;
    size.set(cfg.scale); col.set(cfg.color); bg.set(cfg.bg); bgo.set(cfg.bgOpacity);
    save(); styleBox(id);
  });
  d.append(size.row, col.row, bg.row, bgo.row, rs);
  return d;
}

// Ort für Uhr und Datum (Zeitzone)
function timeZoneOptions(id, cfg) {
  const wrap = el("div");
  const row = el("div", "row");
  const inp = el("input");
  inp.type = "text";
  inp.placeholder = "Ort für die Zeit, z. B. Tokio";
  inp.value = cfg.city || "";
  const go = el("button", "btn small", "Suchen");
  row.append(inp, go);
  const row2 = el("div", "row");
  const local = el("button", "btn gray small", "Meine Ortszeit");
  row2.appendChild(local);
  const status = () => cfg.tz ? `Zeit für: ${cfg.city} (${cfg.tz})` : "Ortszeit dieses Geräts.";
  const st = el("div", "hint", status());
  wrap.append(row, row2, st);

  async function search() {
    const name = inp.value.trim();
    if (!name) return;
    st.textContent = "Suche …";
    try {
      const p = await geocode(name);
      if (!p) { st.textContent = "Ort nicht gefunden."; return; }
      if (!validTz(p.tz)) { st.textContent = "Für diesen Ort gibt es keine Zeitzone."; return; }
      cfg.city = p.city; cfg.tz = p.tz;
      save(); startBody(id);
      st.textContent = status();
    } catch (e) {
      st.textContent = "Suche nicht möglich (keine Verbindung?).";
    }
  }
  go.addEventListener("click", search);
  inp.addEventListener("keydown", (e) => { if (e.key === "Enter") search(); });
  local.addEventListener("click", () => {
    cfg.city = ""; cfg.tz = ""; inp.value = "";
    save(); startBody(id);
    st.textContent = status();
  });
  return wrap;
}

// Ort für das Wetter
function weatherOptions(cfg) {
  const wrap = el("div");
  const row = el("div", "row");
  const inp = el("input");
  inp.type = "text";
  inp.placeholder = "Stadt oder Postleitzahl";
  inp.value = cfg.city && cfg.city !== "Mein Standort" ? cfg.city : "";
  const go = el("button", "btn small", "Suchen");
  row.append(inp, go);

  const row2 = el("div", "row");
  const loc = el("button", "btn gray small", "Meinen Standort verwenden");
  const unit = el("select");
  [["c", "°C"], ["f", "°F"]].forEach(([v, t]) => {
    const op = el("option", null, t);
    op.value = v;
    unit.appendChild(op);
  });
  unit.value = cfg.unit;
  row2.append(loc, unit);

  const st = el("div", "hint", cfg.lat != null ? "Ort: " + (cfg.city || "Mein Standort") : "Noch kein Ort gewählt.");
  wrap.append(row, row2, st);

  async function search() {
    const name = inp.value.trim();
    if (!name) return;
    st.textContent = "Suche …";
    try {
      const p = await geocode(name);
      if (!p) { st.textContent = "Ort nicht gefunden."; return; }
      cfg.city = p.city; cfg.lat = p.lat; cfg.lon = p.lon;
      save(); startBody("weather");
      st.textContent = "Ort: " + cfg.city;
    } catch (e) {
      st.textContent = "Suche nicht möglich (keine Verbindung?).";
    }
  }
  go.addEventListener("click", search);
  inp.addEventListener("keydown", (e) => { if (e.key === "Enter") search(); });

  loc.addEventListener("click", async () => {
    st.textContent = "Standort wird abgefragt …";
    try {
      const p = await whereAmI();
      cfg.lat = p.lat; cfg.lon = p.lon; cfg.city = "Mein Standort";
      inp.value = "";
      save(); startBody("weather");
      st.textContent = "Ort: Mein Standort";
    } catch (e) {
      st.textContent = "Standort nicht verfügbar. Gib stattdessen eine Stadt ein.";
    }
  });

  unit.addEventListener("change", () => { cfg.unit = unit.value; save(); startBody("weather"); });
  return wrap;
}

function buildOptions(id, cfg) {
  const o = el("div", "opts");
  if (id === "clock") {
    o.appendChild(timeZoneOptions(id, cfg));
    o.appendChild(checkbox("Sekunden anzeigen", cfg.seconds, (v) => { cfg.seconds = v; save(); startBody("clock"); }));
    o.appendChild(checkbox("12-Stunden-Anzeige (AM/PM)", cfg.h12, (v) => { cfg.h12 = v; save(); startBody("clock"); }));
  } else if (id === "date") {
    o.appendChild(timeZoneOptions(id, cfg));
  } else if (id === "weather") {
    o.appendChild(weatherOptions(cfg));
  } else if (id === "timer") {
    const row = el("div", "row");
    row.appendChild(el("span", "lbl", "Minuten"));
    const n = el("input");
    n.type = "number"; n.min = "1"; n.max = "180"; n.value = cfg.minutes;
    n.addEventListener("change", () => {
      cfg.minutes = Math.max(1, Math.min(180, Math.round(Number(n.value) || 5)));
      n.value = cfg.minutes;
      save(); startBody("timer");
    });
    row.appendChild(n);
    o.appendChild(row);
  }
  o.appendChild(lookOptions(id, cfg));
  return o;
}

function renderPicker() {
  const list = $("#pickList");
  list.textContent = "";
  for (const id of Object.keys(WIDGETS)) {
    const def = WIDGETS[id];
    const cfg = settings.widgets[id];
    const item = el("div", "pitem");
    const top = el("div", "top");
    top.appendChild(el("div", "ic", def.icon));
    const txt = el("div", "txt");
    txt.append(el("div", "nm", def.name), el("div", "ds", def.desc));
    top.appendChild(txt);
    const b = el("button", "btn small" + (cfg.on ? " on" : ""), cfg.on ? "Entfernen" : "Hinzufügen");
    b.addEventListener("click", () => {
      cfg.on = !cfg.on;
      save(); syncWidgets(); renderPicker();
    });
    top.appendChild(b);
    item.appendChild(top);
    if (cfg.on) item.appendChild(buildOptions(id, cfg));
    list.appendChild(item);
  }
}

// ---------- Panels (Stift und Plus) ----------
const overlay = $("#overlay");
const openSettings = () => overlay.classList.add("open");
const closeSettings = () => overlay.classList.remove("open");
const openPicker = () => { renderPicker(); picker.classList.add("open"); };
const closePicker = () => picker.classList.remove("open");

$("#pen").addEventListener("click", () => {
  if (picker.classList.contains("open")) { closePicker(); return; }
  overlay.classList.toggle("open");
});
$("#close").addEventListener("click", closeSettings);
$("#plus").addEventListener("click", () => { closeSettings(); openPicker(); });
$("#pickBack").addEventListener("click", () => { closePicker(); openSettings(); });
$("#pickClose").addEventListener("click", closePicker);

document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (picker.classList.contains("open")) closePicker(); else closeSettings();
});

// ---------- Einstellungen ----------
$("#barColor").addEventListener("input", (e) => { settings.barColor = e.target.value; saveSoon(); apply(); });
$("#barOpacity").addEventListener("input", (e) => { settings.barOpacity = Number(e.target.value); saveSoon(); apply(); });
$("#titleScale").addEventListener("input", (e) => { settings.layout.title.scale = Number(e.target.value); saveSoon(); apply(); });
$("#titleColor").addEventListener("input", (e) => { settings.layout.title.color = e.target.value; saveSoon(); apply(); });
$("#searchScale").addEventListener("input", (e) => { settings.layout.search.scale = Number(e.target.value); saveSoon(); apply(); });
$("#searchOpacity").addEventListener("input", (e) => { settings.searchOpacity = Number(e.target.value); saveSoon(); apply(); });
$("#font").addEventListener("change", (e) => { settings.font = e.target.value; save(); apply(); });
$("#fontCustom").addEventListener("input", (e) => { settings.fontCustom = e.target.value; saveSoon(); apply(); });

$("#pick").addEventListener("click", () => $("#file").click());
$("#file").addEventListener("change", (e) => {
  const f = e.target.files[0];
  e.target.value = ""; // damit dieselbe Datei erneut gewählt werden kann
  if (!f) return;
  message("");
  if (f.type.startsWith("video/")) handleVideo(f); else handleImage(f);
});

function handleImage(f) {
  const img = new Image();
  img.onload = async () => {
    const max = 2560;
    const scale = Math.min(1, max / img.width);
    const c = document.createElement("canvas");
    c.width = Math.round(img.width * scale);
    c.height = Math.round(img.height * scale);
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    URL.revokeObjectURL(img.src);
    await clearVideo();
    settings.image = c.toDataURL("image/jpeg", 0.88);
    save(); apply();
    message("Bild übernommen.");
  };
  img.onerror = () => message("Das Bild konnte nicht gelesen werden.", true);
  img.src = URL.createObjectURL(f);
}

function handleVideo(f) {
  if (f.size > MAX_VIDEO_BYTES) {
    message(`Die Datei ist zu groß (höchstens ${MAX_VIDEO_BYTES / 1048576} MB).`, true);
    return;
  }
  const url = URL.createObjectURL(f);
  const probeVideo = document.createElement("video");
  probeVideo.preload = "metadata";
  probeVideo.onloadedmetadata = async () => {
    const dur = probeVideo.duration;
    URL.revokeObjectURL(url);
    if (!isFinite(dur) || dur > MAX_VIDEO_SECONDS + 0.05) {
      message(`Das Video ist ${isFinite(dur) ? fmtDur(dur) : "zu"} lang. Erlaubt sind höchstens ${MAX_VIDEO_SECONDS / 60} Minuten.`, true);
      return;
    }
    try {
      await dbPut("video", f);
    } catch (e) {
      message("Das Video konnte nicht gespeichert werden.", true);
      return;
    }
    settings.hasVideo = true;
    settings.image = "";
    showVideoBlob(f);
    save(); apply();
    message(`Video übernommen (${fmtDur(dur)}).`);
  };
  probeVideo.onerror = () => {
    URL.revokeObjectURL(url);
    message("Dieses Video kann Chrome nicht abspielen. Am besten MP4 oder WebM nehmen.", true);
  };
  probeVideo.src = url;
}

$("#useUrl").addEventListener("click", async () => {
  const v = $("#url").value.trim();
  if (!v) return;
  await clearVideo();
  settings.image = v;
  save(); apply();
  message("Bild-URL übernommen.");
});

// Setzt nur Hintergrund, Farben, Schrift und Suchfeld-Sichtbarkeit zurück.
// Positionen, Größen, Widgets und Notizen bleiben.
$("#reset").addEventListener("click", async () => {
  await clearVideo();
  settings = Object.assign({}, DEFAULTS, {
    dismissedUpdate: settings.dismissedUpdate,
    widgets: settings.widgets,
    layout: settings.layout
  });
  save(); apply();
  message("Zurückgesetzt.");
});

// Alle Elemente zurück an ihren Startplatz (Größen und Farben bleiben)
$("#resetPos").addEventListener("click", () => {
  for (const id of Object.keys(LAYOUT_DEFAULTS)) {
    settings.layout[id].x = LAYOUT_DEFAULTS[id].x;
    settings.layout[id].y = LAYOUT_DEFAULTS[id].y;
  }
  for (const id of Object.keys(WIDGET_DEFAULTS)) {
    settings.widgets[id].x = WIDGET_DEFAULTS[id].x;
    settings.widgets[id].y = WIDGET_DEFAULTS[id].y;
  }
  save();
  for (const id of [...Object.keys(STATIC), ...Object.keys(mounted)]) styleBox(id);
  message("Positionen zurückgesetzt.");
});

// ---------- Start ----------
enableDrag("title", $("#title .grip"));
enableDrag("search", $("#searchbox .grip"));
chrome.storage.local.get(KEY, (res) => {
  settings = mergeSettings(res && res[KEY]);
  apply();
  syncWidgets();
  loadSavedVideo();
  showUpdate();
});
$("#q").focus();
